﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecyte
{
    public class Conceptos
    {
        public int Id { get; set; }
        public string Codigo { get; set; }
        public string Denominacion { get; set; }
        public string Zona { get; set; }
    }
}
