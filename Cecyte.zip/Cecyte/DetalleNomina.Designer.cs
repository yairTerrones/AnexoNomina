﻿
namespace Cecyte
{
    partial class DetalleNomina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Num Empleado";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(131, 18);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(58, 20);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(131, 44);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(58, 20);
            this.textBox2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Clave de PU";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(131, 70);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(58, 20);
            this.textBox3.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "Nombre Trabajador";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(131, 96);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(58, 20);
            this.textBox4.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "RFC";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(131, 122);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(58, 20);
            this.textBox5.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "CURP";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(131, 148);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(58, 20);
            this.textBox6.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "Departamento";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(131, 174);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(58, 20);
            this.textBox7.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 12);
            this.label7.TabIndex = 12;
            this.label7.Text = "Puesto";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(131, 207);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(58, 20);
            this.textBox8.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 12);
            this.label8.TabIndex = 14;
            this.label8.Text = "Centro de Costos";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(131, 234);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(58, 20);
            this.textBox9.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 12);
            this.label9.TabIndex = 16;
            this.label9.Text = "Fecha de Alt";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(131, 263);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(58, 20);
            this.textBox10.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(27, 271);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 12);
            this.label10.TabIndex = 18;
            this.label10.Text = "Homologado";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(25, 371);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 12);
            this.label11.TabIndex = 20;
            this.label11.Text = "Carga Hom";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(24, 396);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Licencia";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(25, 423);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 12);
            this.label13.TabIndex = 24;
            this.label13.Text = "Horas Int";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(25, 449);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 12);
            this.label14.TabIndex = 26;
            this.label14.Text = "Sueldo Base Adm";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(25, 475);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 12);
            this.label15.TabIndex = 28;
            this.label15.Text = "Hrs Base Academ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(27, 501);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 12);
            this.label16.TabIndex = 30;
            this.label16.Text = "Hrs Int Academ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(24, 527);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 12);
            this.label17.TabIndex = 32;
            this.label17.Text = "Despensa Adm";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(25, 551);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 12);
            this.label18.TabIndex = 34;
            this.label18.Text = "Falta Días";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(25, 579);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 12);
            this.label19.TabIndex = 36;
            this.label19.Text = "Falta Hrs";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(25, 608);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 12);
            this.label20.TabIndex = 38;
            this.label20.Text = "Compen Sueldo";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(24, 709);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(74, 12);
            this.label21.TabIndex = 40;
            this.label21.Text = "Ajuste de Hrs";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(203, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(74, 12);
            this.label22.TabIndex = 42;
            this.label22.Text = "Prima de Ant.";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(203, 48);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(86, 12);
            this.label23.TabIndex = 44;
            this.label23.Text = "Retro Prima Ant";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(201, 76);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 12);
            this.label24.TabIndex = 46;
            this.label24.Text = "Despensa Acad.";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(201, 96);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(102, 12);
            this.label25.TabIndex = 48;
            this.label25.Text = "Retroactivo Sueldo";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(201, 123);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(102, 12);
            this.label26.TabIndex = 50;
            this.label26.Text = "Comp. Garantizada";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(195, 152);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(108, 12);
            this.label27.TabIndex = 52;
            this.label27.Text = "Comp Se Especiales";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(201, 177);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(101, 12);
            this.label28.TabIndex = 54;
            this.label28.Text = "Apoyo por Servicio";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(195, 211);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(104, 12);
            this.label29.TabIndex = 56;
            this.label29.Text = "Efici en E Trab Adm";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(201, 236);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(98, 12);
            this.label30.TabIndex = 58;
            this.label30.Text = "Efic en E Tra Doce";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(214, 579);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(67, 12);
            this.label31.TabIndex = 78;
            this.label31.Text = "Punt y Asist";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(203, 553);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(92, 12);
            this.label32.TabIndex = 76;
            this.label32.Text = "Dias Economicos";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(192, 527);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(110, 12);
            this.label33.TabIndex = 74;
            this.label33.Text = "Mat Di Jorn 3/4 Tiem";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(192, 500);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(110, 12);
            this.label34.TabIndex = 72;
            this.label34.Text = "Mat Di Jorn 1/2 Tiem";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(203, 475);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(91, 12);
            this.label35.TabIndex = 70;
            this.label35.Text = "Efici Trab Jor 3/4";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(203, 445);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(91, 12);
            this.label36.TabIndex = 68;
            this.label36.Text = "Efici Trab Jor 1/2";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(198, 423);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(104, 12);
            this.label37.TabIndex = 66;
            this.label37.Text = "Sueldo Jor 3/4 Tiem";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(198, 397);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(104, 12);
            this.label38.TabIndex = 64;
            this.label38.Text = "Sueldo Jor 1/2 Tiem";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(196, 371);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(106, 12);
            this.label39.TabIndex = 62;
            this.label39.Text = "Lic Sindical Jornada";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(214, 345);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 12);
            this.label40.TabIndex = 60;
            this.label40.Text = "Dif de Sueldo";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(995, 543);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(51, 20);
            this.textBox41.TabIndex = 99;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(390, 207);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(98, 12);
            this.label41.TabIndex = 98;
            this.label41.Text = "Gastos Funerarios";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(995, 493);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(51, 20);
            this.textBox42.TabIndex = 97;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(390, 178);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(98, 12);
            this.label42.TabIndex = 96;
            this.label42.Text = "Adquisición Libros";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(995, 435);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(51, 20);
            this.textBox43.TabIndex = 95;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(412, 152);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(54, 12);
            this.label43.TabIndex = 94;
            this.label43.Text = "Devo ISR";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(995, 390);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(51, 20);
            this.textBox44.TabIndex = 93;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(390, 123);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(93, 12);
            this.label44.TabIndex = 92;
            this.label44.Text = "Pago de Guardias";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(995, 330);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(51, 20);
            this.textBox45.TabIndex = 91;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(399, 100);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(76, 12);
            this.label45.TabIndex = 90;
            this.label45.Text = "Vales de Nive";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(995, 278);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(51, 20);
            this.textBox46.TabIndex = 89;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(382, 75);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(101, 12);
            this.label46.TabIndex = 88;
            this.label46.Text = "Aguinaldo Gravado";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(995, 231);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(51, 20);
            this.textBox47.TabIndex = 87;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(382, 48);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(93, 12);
            this.label47.TabIndex = 86;
            this.label47.Text = "Aguinaldo Exento";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(995, 173);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(51, 20);
            this.textBox48.TabIndex = 85;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(382, 22);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(98, 12);
            this.label48.TabIndex = 84;
            this.label48.Text = "Ayuda Utiles Esco";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(995, 122);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(51, 20);
            this.textBox49.TabIndex = 83;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(214, 713);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(72, 12);
            this.label49.TabIndex = 82;
            this.label49.Text = "Estimulo Doc";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(993, 71);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(51, 20);
            this.textBox50.TabIndex = 81;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(206, 684);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(86, 12);
            this.label50.TabIndex = 80;
            this.label50.Text = "Dias Ajus Calen";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(131, 315);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(58, 20);
            this.textBox51.TabIndex = 103;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(25, 319);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(77, 12);
            this.label51.TabIndex = 102;
            this.label51.Text = "Carga Interina";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(131, 289);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(58, 20);
            this.textBox52.TabIndex = 101;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(25, 297);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(63, 12);
            this.label52.TabIndex = 100;
            this.label52.Text = "Carga Base";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(24, 657);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(100, 12);
            this.label53.TabIndex = 106;
            this.label53.Text = "Bono Com Equi 1.8";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(24, 633);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(67, 12);
            this.label54.TabIndex = 104;
            this.label54.Text = "Sobresueldo";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(206, 293);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(83, 12);
            this.label55.TabIndex = 110;
            this.label55.Text = "Ajuste de Prest";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(214, 267);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(63, 12);
            this.label56.TabIndex = 108;
            this.label56.Text = "Lic Sindical";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(200, 633);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(103, 12);
            this.label57.TabIndex = 114;
            this.label57.Text = "Prima Vac Gravada";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(208, 607);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(69, 12);
            this.label58.TabIndex = 112;
            this.label58.Text = "Retro de Hrs";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(995, 650);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(51, 20);
            this.textBox59.TabIndex = 119;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(393, 267);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(98, 12);
            this.label59.TabIndex = 118;
            this.label59.Text = "Retro H 2008 2009";
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(995, 600);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(51, 20);
            this.textBox60.TabIndex = 117;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(393, 236);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(87, 12);
            this.label60.TabIndex = 116;
            this.label60.Text = "Premio al merito";
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(131, 341);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(58, 20);
            this.textBox61.TabIndex = 121;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(25, 349);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(79, 12);
            this.label61.TabIndex = 120;
            this.label61.Text = "Otra Categoria";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(26, 684);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(75, 12);
            this.label62.TabIndex = 122;
            this.label62.Text = "Ajuste Sueldo";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(206, 319);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(93, 12);
            this.label63.TabIndex = 124;
            this.label63.Text = "Ayuda para Trans";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(206, 658);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(89, 12);
            this.label64.TabIndex = 126;
            this.label64.Text = "Prim Vac Exenta";
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(995, 693);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(51, 20);
            this.textBox65.TabIndex = 129;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(396, 297);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(95, 12);
            this.label65.TabIndex = 128;
            this.label65.Text = "Retro Prest Homo";
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(1172, 71);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(51, 20);
            this.textBox66.TabIndex = 131;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(396, 323);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(89, 12);
            this.label66.TabIndex = 130;
            this.label66.Text = "Vales Día Madre";
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(1174, 122);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(51, 20);
            this.textBox67.TabIndex = 133;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(399, 345);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(83, 12);
            this.label67.TabIndex = 132;
            this.label67.Text = "Retro Prima 1%";
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(1174, 173);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(51, 20);
            this.textBox68.TabIndex = 135;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(1064, 177);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(82, 12);
            this.label68.TabIndex = 134;
            this.label68.Text = "Bono Día Padre";
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(1174, 231);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(51, 20);
            this.textBox69.TabIndex = 137;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(1064, 235);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(69, 13);
            this.label69.TabIndex = 136;
            this.label69.Text = "Hrs Fortale";
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(1174, 281);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(51, 20);
            this.textBox70.TabIndex = 139;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(1064, 285);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(52, 13);
            this.label70.TabIndex = 138;
            this.label70.Text = "Viaticos";
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(1174, 333);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(51, 20);
            this.textBox71.TabIndex = 141;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(1064, 337);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(107, 13);
            this.label71.TabIndex = 140;
            this.label71.Text = "Retardo y Tiempo";
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(1174, 390);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(51, 20);
            this.textBox72.TabIndex = 143;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(1064, 394);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(107, 13);
            this.label72.TabIndex = 142;
            this.label72.Text = "Efici Trab Hrs For";
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(1174, 435);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(51, 20);
            this.textBox73.TabIndex = 145;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(1064, 439);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(75, 13);
            this.label73.TabIndex = 144;
            this.label73.Text = "Pract. Profe";
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(1174, 496);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(51, 20);
            this.textBox74.TabIndex = 147;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(1064, 500);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(84, 13);
            this.label74.TabIndex = 146;
            this.label74.Text = "Ayuda Lentes";
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(1174, 550);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(51, 20);
            this.textBox75.TabIndex = 149;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(1064, 554);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(101, 13);
            this.label75.TabIndex = 148;
            this.label75.Text = "Apoyo Guarderia";
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(1174, 597);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(51, 20);
            this.textBox76.TabIndex = 151;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(1064, 601);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(113, 13);
            this.label76.TabIndex = 150;
            this.label76.Text = "Ayuda Canas Mate";
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(1174, 657);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(51, 20);
            this.textBox77.TabIndex = 153;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(1064, 661);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(73, 13);
            this.label77.TabIndex = 152;
            this.label77.Text = "Act y Produ";
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(1174, 701);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(51, 20);
            this.textBox78.TabIndex = 155;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(1064, 705);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(80, 13);
            this.label78.TabIndex = 154;
            this.label78.Text = "Despensa Jo";
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(131, 367);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(58, 20);
            this.textBox79.TabIndex = 156;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(131, 393);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(58, 20);
            this.textBox80.TabIndex = 157;
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(131, 419);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(58, 20);
            this.textBox81.TabIndex = 158;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(131, 445);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(58, 20);
            this.textBox82.TabIndex = 159;
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(131, 471);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(58, 20);
            this.textBox83.TabIndex = 160;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(131, 497);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(58, 20);
            this.textBox84.TabIndex = 161;
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(131, 523);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(58, 20);
            this.textBox85.TabIndex = 162;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(131, 549);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(58, 20);
            this.textBox86.TabIndex = 163;
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(131, 575);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(58, 20);
            this.textBox87.TabIndex = 164;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(131, 603);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(58, 20);
            this.textBox88.TabIndex = 165;
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(131, 629);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(58, 20);
            this.textBox89.TabIndex = 166;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(131, 654);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(58, 20);
            this.textBox90.TabIndex = 167;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(131, 680);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(58, 20);
            this.textBox91.TabIndex = 168;
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(131, 706);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(58, 20);
            this.textBox92.TabIndex = 169;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(309, 18);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(58, 20);
            this.textBox11.TabIndex = 170;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(309, 44);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(58, 20);
            this.textBox12.TabIndex = 171;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(309, 70);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(58, 20);
            this.textBox13.TabIndex = 172;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(309, 92);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(58, 20);
            this.textBox14.TabIndex = 173;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(309, 119);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(58, 20);
            this.textBox15.TabIndex = 174;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(309, 148);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(58, 20);
            this.textBox16.TabIndex = 175;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(309, 174);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(58, 20);
            this.textBox17.TabIndex = 176;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(309, 205);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(58, 20);
            this.textBox18.TabIndex = 177;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(309, 231);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(58, 20);
            this.textBox19.TabIndex = 178;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(309, 263);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(58, 20);
            this.textBox20.TabIndex = 179;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(309, 289);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(58, 20);
            this.textBox21.TabIndex = 180;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(309, 315);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(58, 20);
            this.textBox53.TabIndex = 181;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(309, 341);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(58, 20);
            this.textBox54.TabIndex = 182;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(309, 367);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(58, 20);
            this.textBox22.TabIndex = 183;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(309, 393);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(58, 20);
            this.textBox24.TabIndex = 184;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(309, 419);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(58, 20);
            this.textBox62.TabIndex = 185;
            // 
            // textBox93
            // 
            this.textBox93.Location = new System.Drawing.Point(309, 441);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(58, 20);
            this.textBox93.TabIndex = 186;
            // 
            // textBox94
            // 
            this.textBox94.Location = new System.Drawing.Point(309, 471);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(58, 20);
            this.textBox94.TabIndex = 187;
            // 
            // textBox95
            // 
            this.textBox95.Location = new System.Drawing.Point(309, 497);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(58, 20);
            this.textBox95.TabIndex = 188;
            // 
            // textBox96
            // 
            this.textBox96.Location = new System.Drawing.Point(309, 523);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(58, 20);
            this.textBox96.TabIndex = 189;
            // 
            // textBox97
            // 
            this.textBox97.Location = new System.Drawing.Point(309, 549);
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(58, 20);
            this.textBox97.TabIndex = 190;
            // 
            // textBox98
            // 
            this.textBox98.Location = new System.Drawing.Point(309, 575);
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new System.Drawing.Size(58, 20);
            this.textBox98.TabIndex = 191;
            // 
            // textBox99
            // 
            this.textBox99.Location = new System.Drawing.Point(309, 603);
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new System.Drawing.Size(58, 20);
            this.textBox99.TabIndex = 192;
            // 
            // textBox100
            // 
            this.textBox100.Location = new System.Drawing.Point(309, 629);
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(58, 20);
            this.textBox100.TabIndex = 193;
            // 
            // textBox101
            // 
            this.textBox101.Location = new System.Drawing.Point(309, 653);
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(58, 20);
            this.textBox101.TabIndex = 194;
            // 
            // textBox102
            // 
            this.textBox102.Location = new System.Drawing.Point(309, 680);
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(58, 20);
            this.textBox102.TabIndex = 195;
            // 
            // textBox103
            // 
            this.textBox103.Location = new System.Drawing.Point(309, 709);
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(58, 20);
            this.textBox103.TabIndex = 196;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(511, 18);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(58, 20);
            this.textBox23.TabIndex = 197;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(511, 44);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(58, 20);
            this.textBox25.TabIndex = 198;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(511, 72);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(58, 20);
            this.textBox26.TabIndex = 199;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(511, 96);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(58, 20);
            this.textBox27.TabIndex = 200;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(511, 122);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(58, 20);
            this.textBox28.TabIndex = 201;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(511, 148);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(58, 20);
            this.textBox29.TabIndex = 202;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(511, 174);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(58, 20);
            this.textBox30.TabIndex = 203;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(511, 203);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(58, 20);
            this.textBox31.TabIndex = 204;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(511, 232);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(58, 20);
            this.textBox32.TabIndex = 205;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(511, 263);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(58, 20);
            this.textBox33.TabIndex = 206;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(511, 293);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(58, 20);
            this.textBox34.TabIndex = 207;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(511, 319);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(58, 20);
            this.textBox35.TabIndex = 208;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(511, 345);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(58, 20);
            this.textBox36.TabIndex = 209;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(511, 371);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(58, 20);
            this.textBox37.TabIndex = 210;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(511, 397);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(58, 20);
            this.textBox38.TabIndex = 211;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(511, 423);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(58, 20);
            this.textBox39.TabIndex = 212;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(511, 445);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(58, 20);
            this.textBox40.TabIndex = 213;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(511, 471);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(58, 20);
            this.textBox55.TabIndex = 214;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(511, 497);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(58, 20);
            this.textBox56.TabIndex = 215;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(511, 523);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(58, 20);
            this.textBox57.TabIndex = 216;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(511, 549);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(58, 20);
            this.textBox58.TabIndex = 217;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(511, 575);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(58, 20);
            this.textBox63.TabIndex = 218;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(511, 604);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(58, 20);
            this.textBox64.TabIndex = 219;
            // 
            // textBox104
            // 
            this.textBox104.Location = new System.Drawing.Point(511, 630);
            this.textBox104.Name = "textBox104";
            this.textBox104.Size = new System.Drawing.Size(58, 20);
            this.textBox104.TabIndex = 220;
            // 
            // textBox105
            // 
            this.textBox105.Location = new System.Drawing.Point(511, 654);
            this.textBox105.Name = "textBox105";
            this.textBox105.Size = new System.Drawing.Size(58, 20);
            this.textBox105.TabIndex = 221;
            // 
            // textBox106
            // 
            this.textBox106.Location = new System.Drawing.Point(511, 680);
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new System.Drawing.Size(58, 20);
            this.textBox106.TabIndex = 222;
            // 
            // textBox107
            // 
            this.textBox107.Location = new System.Drawing.Point(511, 709);
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(58, 20);
            this.textBox107.TabIndex = 223;
            // 
            // DetalleNomina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.textBox107);
            this.Controls.Add(this.textBox106);
            this.Controls.Add(this.textBox105);
            this.Controls.Add(this.textBox104);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox103);
            this.Controls.Add(this.textBox102);
            this.Controls.Add(this.textBox101);
            this.Controls.Add(this.textBox100);
            this.Controls.Add(this.textBox99);
            this.Controls.Add(this.textBox98);
            this.Controls.Add(this.textBox97);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "DetalleNomina";
            this.Text = "DetalleNomina";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox107;
    }
}