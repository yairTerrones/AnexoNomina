﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cecyte
{
    public class Prestacion
    {
        public int Id { get; set; }
        public string Concepto { get; set; }
        public string Puesto { get; set; }
        public string Total { get; set; }       
    }
}
